require.config({
	paths: {}
});
define(["jquery", "SynerJ", "require",
        "js/data.js"], 
	function($, SynerJ, require) {
window.SynerJ = SynerJ;
});

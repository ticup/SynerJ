define(['js/jquery-bare.js'], function () {
		return window.jQuery;
});

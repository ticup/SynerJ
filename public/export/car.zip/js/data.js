require(['SynerJ'], function (SynerJ) {
SynerJ('car').setProp('prototype', 'object:carProto');
SynerJ('car').setProp('sirene', 'object:sirene');
SynerJ('car').setProp('ignite', function alarm() {
    var sirene = this.sirene;
    var car = this;
    var step = this.step;
    
    this.running = true;
    
    function up() {
        sirene.setCss('background-color', 'green');
        if (car.running) {
            var xDist = car.xDist;
            var yDist = car.yDist;
            if (car.xDist) {
                if (Math.abs(xDist) < step) {
                    return car.xDist = false;
                }
                var dst = (xDist > 0) ? step : - step;
                car.horizontal();
                car.setCss('left', parseInt(car.getCss('left')) + dst + "px");
                car.xDist = car.xDist - dst;  
            } else if (car.yDist) {
                if (Math.abs(yDist) < step) {
                    alert('Your car has arrived!');
                    return car.yDist = false;
                }
                var dst = (yDist > 0) ? step : - step;
                car.vertical();
                car.setCss('top', parseInt(car.getCss('top')) + dst + "px");
                car.yDist = car.yDist - dst;  
            }
            setTimeout(down, 100);
        }
    }
    function down() {
        sirene.setCss('background-color', 'red');
        setTimeout(up, 100);
    }
    up();   
});
SynerJ('car').setProp('stop', function stop() {
    this.running = false;
});
SynerJ('car').setProp('horizontal', function horizontal() {
    if (this.position != "horizontal") {
        this.turn();
        this.position = "horizontal";
    }
});
SynerJ('car').setProp('position', 'vertical');
SynerJ('car').setProp('vertical', function vertical() {
    if (this.position != "vertical") {
        this.turn();
        this.position = "vertical";
    }
});
SynerJ('car').setProp('turn', function turn() {
    function swapCss(obj, a, b) {
        var c = obj.getCss(a);
        obj.setCss(a, obj.getCss(b));
        obj.setCss(b, c);
    }
    
    var children = this.children();
    for (var i in children) {
        swapCss(children[i], "top", "left");
    }
    swapCss(this, "width", "height");
    
    console.log('turning');  
});
SynerJ('car').setProp('xDist', 0);
SynerJ('car').setProp('yDist', 0);
SynerJ('car').setProp('running', false);
SynerJ('car').setProp('step', 10);
SynerJ('car').setProp('drive', function goto(x, y) {
    this.xDist = x;
    this.yDist = y;
});
SynerJ('car').setProp('foo', 'bar');
SynerJ('wheel1').setProp('prototype', 'object:wheelProto');
SynerJ('wheel2').setProp('prototype', 'object:wheelProto');
SynerJ('wheel3').setProp('prototype', 'object:wheelProto');
SynerJ('wheel4').setProp('prototype', 'object:wheelProto');
SynerJ('wheelProto').setProp('prototype', '');
SynerJ('carProto').setProp('prototype', 'object:red');
SynerJ('red').setProp('prototype', '');
SynerJ('start').bind('click', function (event) {
    SynerJ('car').ignite();
});
SynerJ('stop').bind('click', function (event) {
    SynerJ('car').stop();
});
SynerJ('go-to').bind('click', function onClick(event) {
    var x = SynerJ('x-input').val();
    var y = SynerJ('y-input').val();
    SynerJ('car').drive(x, y);
});
});